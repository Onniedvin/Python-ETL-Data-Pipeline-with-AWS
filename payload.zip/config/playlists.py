def spotify_playlists():
    playlists = {'struttin': 'spotify:playlist:5Xje7Vozisgteekl3z1O7K'}
    return playlists


#def personal_playlists():
#    playlists = {'struttin': 'spotify:playlist:5Xje7Vozisgteekl3z1O7K'}
#    return playlists
